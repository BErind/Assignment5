package iss.java.mail;

import java.io.IOException;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPStore;

import java.util.List;
import java.util.Properties;

public class IMP2014302580059 implements IMailService {
    /**
     * 发送邮件的props文件
     */
    private final transient Properties props = System.getProperties();
    /**
     * 邮件服务器登录验证
     */
    private transient AUT2014302580059 authenticator;

    /**
     * 邮箱session
     */
    private transient Session session;
    
    /**
     * 接收邮件的props文件
     */
    private final transient Properties props1 = System.getProperties();
    /**
     * 邮件服务器登录验证
     */
    private transient AUT2014302580059 authenticator1;

    /**
     * 邮箱session
     */
    private transient Session session1;
    
    private IMAPFolder folder= null;
    private IMAPStore store=null;
    
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
        // 初始化props
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.exmail.qq.com");
        // 验证
        authenticator = new AUT2014302580059("testrobot@angelbeats.moe", "password");
        // 创建session
        session = Session.getInstance(props, authenticator);
        
        // 初始化props1
        props1.put("mail.imap.auth.plain.disable","true");
        props1.put("mail.imap.host","imap.exmail.qq.com");
        // 验证
        authenticator1 = new AUT2014302580059("testrobot@angelbeats.moe", "password");
        // 创建session
        session1 = Session.getInstance(props1,authenticator1);
	}

	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
        // 创建mime类型邮件
        final MimeMessage message = new MimeMessage(session);
        // 设置发信人
        message.setFrom(new InternetAddress(authenticator.getUsername()));
        // 设置收件人
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        // 设置主题
        message.setSubject(subject);
        // 设置邮件内容
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // 发送
        Transport.send(message);
	}

	@Override
	public boolean listen() throws MessagingException {
        int total= 0;
        store=(IMAPStore)session1.getStore("imap");  // 使用imap会话机制，连接服务器
        store.connect("imap.exmail.qq.com","testrobot@angelbeats.moe","password");
        folder=(IMAPFolder)store.getFolder("INBOX"); //收件箱 
        // 使用只读方式打开收件箱 
        folder.open(Folder.READ_WRITE);
        //获取总邮件数
        total = folder.getMessageCount(); 
        if(total!=0)
        	return true;
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
        Message[] messages = folder.getMessages();  
        for (int i = 0; i < messages.length; i++) {  
            Message message = messages[i];  
            if(message.getSubject().equals(subject))
            	return (String) message.getContent();
        }
		// TODO Auto-generated method stub
		return null;
	}

}
